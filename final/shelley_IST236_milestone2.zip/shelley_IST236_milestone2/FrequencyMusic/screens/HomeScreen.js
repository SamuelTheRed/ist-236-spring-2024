import { Text } from "react-native";

// Home Screen
function HomeScreen() {
  return <Text>This is the App Home</Text>;
}

export default HomeScreen;
