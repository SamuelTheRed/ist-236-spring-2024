import { Text } from "react-native";

//  Screen
function  LessonsScreen() {
  return <Text>This is the Music Lesson Screen</Text>;
}

export default LessonsScreen;
