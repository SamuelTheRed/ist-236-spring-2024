import { Text } from "react-native";

//  Screen
function  StoreScreen() {
  return <Text>This is the Music Store Screen</Text>;
}

export default StoreScreen;
