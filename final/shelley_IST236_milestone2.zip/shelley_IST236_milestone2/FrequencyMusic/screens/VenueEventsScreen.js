import { Text } from "react-native";

//  Screen
function  VenueScreen() {
  return <Text>This is the Music Store Screen</Text>;
}

export default VenueScreen;
